# NetScan v1.0.2

Home network scanner: lists devices on your LAN. Java 21, Spring Boot 3.3, Maven. Offline, no account.

## Run
```
mvn test
mvn spring-boot:run
```
Then open: http://localhost:8080/api/devices (add `?refresh=true` to force a new scan).

| Endpoint | Returns |
|---|---|
| GET /api/devices | scan result: network, time, devices (ip, mac, reachable, self) |
| GET /api/network | detected interface and subnet |
| GET /api/info | app version (from pom), OS, Java |
| GET /api/saved[?known=true/false] | remembered devices (label, known, firstSeen, lastSeen) |
| PATCH /api/saved/{id} | JSON body with optional label and known |
| DELETE /api/saved/{id} | forget a device |
| GET /api/events[?deviceId=&limit=50] | history: JOINED / ONLINE / OFFLINE, newest first |
| GET /api/status | last scan time, interval, scheduler on/off |

## Radar page
Open http://localhost:8080/ : devices appear as dots on a radar. Green = known, red (pulsing) = unknown, grey = offline, cyan = this computer. Click a dot to label it, mark it known, or forget it. The page reads stored data every 15 s; "Scan now" forces a scan.

## Automatic scans
Every 5 minutes (`netscan.scan-interval=PT5M`). A device goes offline after 2 missed scans (`netscan.offline-after-misses`). Events older than 90 days are deleted nightly.

## Data
Devices are stored in `./data/netscan.mv.db` (H2 file, Flyway migrations). Copy the data folder to back up. Device key = MAC address.

## Notes
- Run directly on your machine, not in Docker (a container cannot see your LAN).
- Listens on 127.0.0.1 only until login exists (v1.0.5).
- Only scan networks you own or may scan.
- Docs: `docs/BLUEPRINT.md` (project memory), `docs/TESTING.md`, `CHANGELOG.md`.
