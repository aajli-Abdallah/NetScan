# Manual tests

## 1.0.2
1. `mvn test` passes (new change-detection tests, migration V2 validated).
2. Start the app. After about 20 s the log shows "Scheduled scan: N devices". Repeats every 5 min.
3. Open http://localhost:8080/ : radar sweeps, your devices appear as dots, status line shows last scan and counts.
4. Click a dot: label it, tick Known, Save. The dot turns green, the label appears under it.
5. Switch a phone's Wi-Fi off. After 2 scans (about 10 min) it turns grey and Activity shows "went offline". Switch it on: "came online" after the next scan.
6. Press "Scan now": the button shows Scanning, then the page updates.
7. `/api/events?limit=10` and `/api/status` return JSON.
8. Disconnect the PC from the network during a scan: log warns, no events are created, devices are not marked offline.
9. Set `netscan.scheduler.enabled=false`: no scheduled scans, status says auto-scan off.
Report: stack trace if start fails (a validation error on `online`, `missed` or the events table would be a small fix in V2).

## 1.0.1
1. `mvn test` passes (includes migration + repository test).
2. Start the app: a `data/` folder appears. `/api/devices` items now have id, known, firstSeen, lastSeen. Your PC: known=true.
3. Label one device (replace ID). Windows cmd keeps the escaped quotes; or use Postman/Bruno:
   `curl -X PATCH http://localhost:8080/api/saved/ID -H "Content-Type: application/json" -d "{\"label\":\"Dad phone\",\"known\":true}"`
4. Stop and restart: label and known are still there, firstSeen unchanged, lastSeen newer.
5. `/api/saved?known=false` lists only unknown devices.
6. Switch a phone off: it stays in `/api/saved`, its lastSeen stops moving.
7. DELETE `/api/saved/ID` returns 204; the next scan adds it back as unknown.
8. PATCH a wrong id: 404. Label longer than 100 chars: 400.
Report: stack trace if the app fails at start (a schema validation error would mean the timestamp column type needs a small fix).

## 1.0.0
1. `mvn test` passes (CIDR + ARP parser tests).
2. `mvn spring-boot:run` starts, no errors.
3. `/api/info` shows version 1.0.0.
4. `/api/network` shows your LAN IP, correct subnet, and the right interface (not Docker/VM).
5. `/api/devices`: your router and your own PC (self=true) appear with MACs.
6. Turn on a phone's Wi-Fi, call `/api/devices?refresh=true`: it appears. Turn off, wait 1-2 min, refresh: reachable=false or gone.
7. Disconnect from the network: `/api/network` returns 503 with a clear message.
8. Call `/api/devices` twice within 10 s: second answer is instant (cache).
Report: OS, Java version, and any stack trace.
