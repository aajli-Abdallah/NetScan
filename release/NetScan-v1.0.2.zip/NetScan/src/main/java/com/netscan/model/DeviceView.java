package com.netscan.model;

import java.time.Instant;

/** Scanned device merged with stored data. reachable = answered this scan; online = debounced state. */
public record DeviceView(String id, String ip, String mac, String label, boolean known, boolean online,
                         boolean reachable, boolean self, Instant firstSeen, Instant lastSeen) {}
