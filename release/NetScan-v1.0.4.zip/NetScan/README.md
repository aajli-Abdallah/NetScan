# NetScan v1.0.4

Home network scanner: lists devices on your LAN. Java 21, Spring Boot 3.3, Maven. Offline, no account.

## Run
```
mvn test
mvn spring-boot:run
```
Then open: http://localhost:8080/api/devices (add `?refresh=true` to force a new scan).

| Endpoint | Returns |
|---|---|
| GET /api/devices | scan result: network, time, devices (ip, mac, reachable, self) |
| GET /api/network | detected interface and subnet |
| GET /api/info | app version (from pom), OS, Java |
| GET /api/saved[?known=true/false] | remembered devices (label, known, firstSeen, lastSeen) |
| PATCH /api/saved/{id} | JSON body with optional label and known |
| DELETE /api/saved/{id} | forget a device |
| GET /api/events[?deviceId=&limit=50] | history: JOINED / ONLINE / OFFLINE, newest first |
| GET /api/status | last scan time, interval, scheduler on/off |
| POST /api/saved/{id}/portscan | quick TCP scan of common ports (device must be online) |
| GET /api/stream | live events (Server-Sent Events) used by the radar page |
| POST /api/alerts/test | sends a test alert to the page and to the webhook |

## Radar page
Open http://localhost:8080/ : devices appear as dots on a radar. Green = known, red (pulsing) = unknown, grey = offline, cyan = this computer. Click a dot to label it, mark it known, or forget it. The page reads stored data every 15 s; "Scan now" forces a scan.

## Alerts
An alert fires when a device with a **new MAC address** appears and is not known. The very first scan after a fresh database is a baseline: devices are recorded but no alerts fire.
- Radar page: toast, beep and (after "Enable alerts") a desktop notification, live without reload (green dot = connected).
- Log: a WARN line starting with `ALERT`.
- Phone push (optional, off by default): set `netscan.alert.webhook-url` (or env var `NETSCAN_ALERT_WEBHOOK_URL`) and `netscan.alert.webhook-format`:
  `text` (plain body, works with ntfy.sh topic URLs), `discord` (JSON content), `telegram` or `slack` (JSON text; Telegram URL: `https://api.telegram.org/bot<TOKEN>/sendMessage?chat_id=<ID>`).
- Test it with `curl -X POST http://localhost:8080/api/alerts/test`.
Tip: phones with randomized MACs may look like new devices when they rejoin with a new address.

## Vendor names
Only a few common vendors are built in. For full coverage download the IEEE list once (the app itself stays offline):
`mkdir data` then `curl -L -o data/oui.csv https://standards-oui.ieee.org/oui/oui.csv`, then restart. If the download is blocked, open the URL in a browser and save the file as `data/oui.csv`.
Devices with a randomized (private) MAC show "Private / randomized MAC". Hostnames come from reverse DNS (empty if your router does not answer).

## Port scan
Only on request (button on the radar page), only for an online device NetScan already found, only a short list of common ports (`netscan.quick-ports`).

## Automatic scans
Every 5 minutes (`netscan.scan-interval=PT5M`). A device goes offline after 2 missed scans (`netscan.offline-after-misses`). Events older than 90 days are deleted nightly.

## Data
Devices are stored in `./data/netscan.mv.db` (H2 file, Flyway migrations). Copy the data folder to back up. Device key = MAC address.

## Notes
- Run directly on your machine, not in Docker (a container cannot see your LAN).
- Listens on 127.0.0.1 only until login exists (v1.0.5).
- Only scan networks you own or may scan.
- Docs: `docs/BLUEPRINT.md` (project memory), `docs/TESTING.md`, `CHANGELOG.md`.
