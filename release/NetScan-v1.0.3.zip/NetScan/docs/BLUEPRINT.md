# NetScan Blueprint (project memory)
Update this file on every version. Keep it short and factual.

## Goal
Home network scanner and intruder alert. Offline, no account, learning/portfolio project.

## Stack
Java 21, Spring Boot 3.3.x, Maven. Later: Data JPA, Flyway, H2 -> PostgreSQL, Security, Thymeleaf/SSE, JUnit 5, Mockito.

## Working rules (owner preferences)
- Free plan: concise replies, small patches, no whole-file rewrites for small changes.
- Assistant cannot compile or run code. Owner builds, tests, reports errors. Say "I haven't compiled this".
- Ambiguity: state assumption and proceed; at most one question.
- Before building, check what already exists. Renumber the plan if needed.
- Each version = zip `NetScan-v<version>.zip`. Corrections: 1.0.0 -> 1.0.0.1.
- Every version updates together: pom `<version>`, README title, CHANGELOG (newest first), zip name, this file (status + log).
- Version is read from build-info (BuildProperties), never hard-coded in code.
- Each version ends with a short manual test list (docs/TESTING.md) and next steps.

## Data rules (from 1.0.1)
- Flyway migration for every schema change. `spring.jpa.hibernate.ddl-auto=validate` or none. Never auto-update.
- UUID string ids for entities. Explicit entities (Device, Scan, Sighting), never inferred from timestamps.
- History rows keep a snapshot (ip, mac, label at the time).
- Exports carry appVersion; old exports must stay importable. Decide merge rules before import code.
- Strings/messages centralized; plan i18n early.

## Version map
| Version | Scope | Status |
|---|---|---|
| 1.0.0 | Subnet detection, ping sweep, ARP parse, device list endpoint, tests | DONE |
| 1.0.1 | Persistence (JPA+Flyway), labels, known/unknown, first/last seen | DONE |
| 1.0.2 | Scheduled scans (5 min), online/offline change detection, history, radar page | DONE |
| 1.0.3 | Vendor (OUI) lookup, hostname, quick port scan | DONE |
| 1.0.4 | New-device alerts, live push (SSE), dashboard polish (radar page exists since 1.0.2) | next |
| 1.0.5 | Login, JSON/CSV export, final README/changelog, full blueprint | planned |

## Architecture (1.0.0)
```
web/DeviceController -> scan/ScanService -> scan/NetworkDetector  (interface + subnet)
                                         -> scan/PingSweeper      (virtual-thread probes)
                                         -> arp/ArpReader         (OS pick) -> Linux/Windows/Mac parsers
net/Cidr, net/MacUtil = pure logic (unit tested)
model/ Device, NetworkInfo, ScanResult = records
```
- ScanService is synchronized and caches the last result (netscan.cache-seconds, default 10).
- Device.reachable=false with a MAC = ARP cache only (maybe offline or blocking probes).
- Own machine is always listed (self=true).

## Persistence (1.0.1)
```
ScanService -> store/DeviceStore (@Transactional sync/update/delete) -> store/DeviceRepository -> DeviceEntity (table devices)
web/SavedDeviceController: GET/PATCH/DELETE /api/saved
```
- Table `devices`: id (UUID string), mac (unique, natural key), label, known, last_ip, first_seen, last_seen (UTC timestamps).
- Migrations in src/main/resources/db/migration. ddl-auto=validate. Next migration = V2__*.sql.
- Devices without a MAC are shown in scans but not stored.
- Import merge rule (decide before 1.0.5): match by MAC; newest lastSeen wins for times; label/known need an updatedAt column (add in a later migration if needed).

## Scheduling, history and radar (1.0.2)
- scan/ScanScheduler: @Scheduled fixedDelay (PT5M), initial delay 20 s, nightly purge of old events. Switch: netscan.scheduler.enabled.
- DeviceStore.sync detects changes: JOINED (new MAC), ONLINE (was offline, now reachable), OFFLINE (missed >= netscan.offline-after-misses, default 2).
- Devices absent from a scan are also counted as misses. A failed scan (no network) does not touch the database.
- Table device_events: snapshot columns (mac, label, ip, known), no foreign key, so history survives "forget device".
- devices gets online + missed columns (V2). Event type stored as plain string (avoids Hibernate enum/H2 validation issues).
- web/HistoryController: /api/events, /api/status. static/index.html: radar page, plain JS + Canvas, uses textContent only (labels are user input).
- Possible later: uptime per day from events, per-device event page.

## Enrichment (1.0.3)
- net/OuiLookup: classpath seed `oui-seed.csv` (about 28 entries) then optional `./data/oui.csv` (IEEE csv or `AABBCC,Vendor`). Only 24-bit (MA-L) blocks. Randomized MAC = locally administered bit set.
- scan/HostnameResolver: reverse DNS in virtual threads, shared deadline (netscan.hostname-timeout-ms), runs in every scan for reachable devices.
- scan/PortScanner: TCP connect scan of netscan.quick-ports, triggered only by POST /api/saved/{id}/portscan; not in scheduled scans.
- devices columns (V3): vendor, hostname, open_ports (csv), ports_scanned_at. Vendor is stored once found; hostname refreshed on each reachable scan.
- model/OpenPort maps port numbers to service names.

## Decisions log
- 1.0.0: ARP table read instead of raw sockets: no admin rights, no native libs.
- 1.0.0: "refused" TCP connection counts as alive (host answered).
- 1.0.0: scan range = max(prefix, 24) to avoid sweeping huge subnets. Cidr.hosts() refuses > /16.
- 1.0.0: server.address=127.0.0.1 until login exists.
- 1.0.0: no DB in the first version, keeps the first build small and testable.
- 1.0.1: H2 file DB in ./data (zero setup). PostgreSQL decision postponed to 1.0.5. SQL kept portable.
- 1.0.1: MAC is the identity. Phones with random MACs show as new unknown devices: label them or turn off private MAC for your own network.
- 1.0.1: lastSeen/lastIp only move when a device is reachable (not when only in the ARP cache).
- 1.0.1: this computer is auto-marked known with label 'This computer'.
- 1.0.1: tests include a DataJpaTest so a migration/entity mismatch fails in `mvn test`, not at runtime.
- 1.0.2: scan interval 5 min (owner choice). Offline needs 2 misses (about 10 min) to avoid flapping phones.
- 1.0.2: radar page built now (owner asked for creative design); 1.0.4 keeps alerts and live push.
- 1.0.2: after upgrading from 1.0.1, existing devices produce one ONLINE event on the first scan (online column starts false).
- 1.0.3: no vendor data typed from memory beyond a small verified seed; full list is a one-time user download (keeps app offline, no stale or wrong data).
- 1.0.3: port scan is on demand only, never scheduled, and only targets IPs NetScan itself recorded.
- 1.0.3: Device record got a 4-arg constructor so older code and tests did not change.
- 1.0.3: server.error.include-message=always so the radar page can show API error text (localhost only).

## Known limits / pitfalls
- Phones use random MACs per network: vendor lookup unreliable, labels matter more.
- Guest-isolated Wi-Fi hides devices. IPv4 only. One interface (first match).
- Docker on Windows/Mac cannot see the LAN. Linux needs host networking.
- Windows `arp -a` lists multiple interfaces: filtered by the scan range.
- Java `isReachable` may fall back to TCP without admin rights: hence the TCP probes.
- Firewalls may block probes: a sleeping/locked-down device can look offline.

## Version log
- 1.0.0: initial scanner, see CHANGELOG.md.
- 1.0.1: persistence, labels, known flag, see CHANGELOG.md.
- 1.0.2: scheduler, change detection, history, radar page, see CHANGELOG.md.
- 1.0.3: vendor, hostname, port scan, see CHANGELOG.md.
