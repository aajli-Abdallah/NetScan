package com.netscan.store;

import java.time.Instant;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DeviceEventRepository extends JpaRepository<DeviceEventEntity, String> {
    List<DeviceEventEntity> findAllByOrderByOccurredAtDesc(Pageable page);

    List<DeviceEventEntity> findByDeviceIdOrderByOccurredAtDesc(String deviceId, Pageable page);

    @Modifying
    @Query("delete from DeviceEventEntity e where e.occurredAt < :cutoff")
    int deleteOlderThan(@Param("cutoff") Instant cutoff);
}
