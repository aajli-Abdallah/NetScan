package com.netscan.model;

import java.time.Instant;
import java.util.List;

public record ScanResult(NetworkInfo network, Instant scannedAt, long durationMs,
                         int count, List<DeviceView> devices) {}
