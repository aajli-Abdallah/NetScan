package com.netscan.model;

/** reachable=false with a MAC means "in ARP cache only" (maybe offline or blocking probes). */
public record Device(String ip, String mac, boolean reachable, boolean self, String hostname) {
    public Device(String ip, String mac, boolean reachable, boolean self) {
        this(ip, mac, reachable, self, null);
    }

    public Device withHostname(String h) {
        return new Device(ip, mac, reachable, self, h);
    }
}
