package com.netscan.model;

import java.time.Instant;
import java.util.List;

public record SavedDevice(String id, String mac, String lastIp, String label, String hostname, String vendor,
                          boolean known, boolean online, Instant firstSeen, Instant lastSeen,
                          List<OpenPort> openPorts, Instant portsScannedAt) {}
