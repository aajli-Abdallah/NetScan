package com.netscan.model;

public enum EventType { JOINED, ONLINE, OFFLINE }
