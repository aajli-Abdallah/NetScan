package com.netscan.model;

/** Both fields optional. Empty label clears it. */
public record UpdateRequest(String label, Boolean known) {}
