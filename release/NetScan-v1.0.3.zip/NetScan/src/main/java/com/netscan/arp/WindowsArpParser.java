package com.netscan.arp;

import com.netscan.net.MacUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parses `arp -a` on Windows: "  192.168.1.1   aa-bb-cc-dd-ee-ff   dynamic". */
public class WindowsArpParser implements ArpParser {
    private static final Pattern LINE = Pattern.compile(
            "^\\s*(" + IP + ")\\s+([0-9a-fA-F]{2}(?:-[0-9a-fA-F]{2}){5})\\s+\\w+");

    @Override
    public List<ArpEntry> parse(String raw) {
        List<ArpEntry> out = new ArrayList<>();
        for (String line : raw.split("\\R")) {
            Matcher m = LINE.matcher(line);
            if (!m.find()) continue;
            String mac = MacUtil.normalize(m.group(2));
            if (mac != null) out.add(new ArpEntry(m.group(1), mac));
        }
        return out;
    }
}
