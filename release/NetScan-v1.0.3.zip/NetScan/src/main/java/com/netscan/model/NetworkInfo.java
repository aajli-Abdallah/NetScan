package com.netscan.model;

public record NetworkInfo(String interfaceName, String localIp, String localMac,
                          int prefix, String subnet, String scanRange) {}
