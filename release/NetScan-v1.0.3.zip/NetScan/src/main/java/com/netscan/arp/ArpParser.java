package com.netscan.arp;

import java.util.List;

public interface ArpParser {
    String IP = "\\d{1,3}(?:\\.\\d{1,3}){3}";

    List<ArpEntry> parse(String raw);
}
