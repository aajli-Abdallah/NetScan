package com.netscan.model;

import java.time.Instant;

/** History entry with a snapshot of the device at that moment. */
public record DeviceEvent(String id, String deviceId, String mac, String label, String ip,
                          boolean known, String type, Instant at) {}
