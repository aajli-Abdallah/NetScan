package com.netscan.arp;

public record ArpEntry(String ip, String mac) {}
