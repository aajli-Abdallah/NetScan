package com.netscan.scan;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.InetAddress;
import java.net.ServerSocket;
import org.junit.jupiter.api.Test;

class PortScannerTest {
    @Test void findsOnlyTheOpenPort() throws Exception {
        try (ServerSocket ss = new ServerSocket(0, 50, InetAddress.getLoopbackAddress())) {
            int open = ss.getLocalPort();
            PortScanner scanner = new PortScanner(500, new int[]{open, 1});
            assertThat(scanner.scan("127.0.0.1")).containsExactly(open);
        }
    }
}
