# NetScan v1.0.1

Home network scanner: lists devices on your LAN. Java 21, Spring Boot 3.3, Maven. Offline, no account.

## Run
```
mvn test
mvn spring-boot:run
```
Then open: http://localhost:8080/api/devices (add `?refresh=true` to force a new scan).

| Endpoint | Returns |
|---|---|
| GET /api/devices | scan result: network, time, devices (ip, mac, reachable, self) |
| GET /api/network | detected interface and subnet |
| GET /api/info | app version (from pom), OS, Java |
| GET /api/saved[?known=true/false] | remembered devices (label, known, firstSeen, lastSeen) |
| PATCH /api/saved/{id} | JSON body with optional label and known |
| DELETE /api/saved/{id} | forget a device |

## Data
Devices are stored in `./data/netscan.mv.db` (H2 file, Flyway migrations). Copy the data folder to back up. Device key = MAC address.

## Notes
- Run directly on your machine, not in Docker (a container cannot see your LAN).
- Listens on 127.0.0.1 only until login exists (v1.0.5).
- Only scan networks you own or may scan.
- Docs: `docs/BLUEPRINT.md` (project memory), `docs/TESTING.md`, `CHANGELOG.md`.
