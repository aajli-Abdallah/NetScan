# Changelog (newest first)

## 1.0.1
- Persistence: H2 file database, Spring Data JPA, Flyway (V1__init.sql). Schema validated at start, never auto-changed.
- Devices remembered by MAC (UUID id): label, known flag, firstSeen, lastSeen, lastIp.
- Every scan syncs the database. New device = unknown; this computer = known. Offline devices keep their lastSeen.
- Endpoints: GET /api/saved, PATCH /api/saved/{id}, DELETE /api/saved/{id}. /api/devices now includes id, label, known, firstSeen, lastSeen.
- Tests: DeviceStore logic (Mockito), migration + repository (DataJpaTest).

## 1.0.0
- Subnet detection (skips Docker/VM adapters), scan range clamped to /24 minimum.
- Parallel ping/TCP sweep with virtual threads.
- ARP parsers: Linux (/proc/net/arp), Windows (arp -a), macOS (arp -an), OS auto-selected.
- Endpoints: /api/devices, /api/network, /api/info.
- Unit tests: CIDR math, 3 ARP parsers, MAC normalization.
- Docs folder created (BLUEPRINT, TESTING).
- No database yet (starts in 1.0.1).
