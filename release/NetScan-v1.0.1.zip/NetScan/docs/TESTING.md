# Manual tests

## 1.0.1
1. `mvn test` passes (includes migration + repository test).
2. Start the app: a `data/` folder appears. `/api/devices` items now have id, known, firstSeen, lastSeen. Your PC: known=true.
3. Label one device (replace ID). Windows cmd keeps the escaped quotes; or use Postman/Bruno:
   `curl -X PATCH http://localhost:8080/api/saved/ID -H "Content-Type: application/json" -d "{\"label\":\"Dad phone\",\"known\":true}"`
4. Stop and restart: label and known are still there, firstSeen unchanged, lastSeen newer.
5. `/api/saved?known=false` lists only unknown devices.
6. Switch a phone off: it stays in `/api/saved`, its lastSeen stops moving.
7. DELETE `/api/saved/ID` returns 204; the next scan adds it back as unknown.
8. PATCH a wrong id: 404. Label longer than 100 chars: 400.
Report: stack trace if the app fails at start (a schema validation error would mean the timestamp column type needs a small fix).

## 1.0.0
1. `mvn test` passes (CIDR + ARP parser tests).
2. `mvn spring-boot:run` starts, no errors.
3. `/api/info` shows version 1.0.0.
4. `/api/network` shows your LAN IP, correct subnet, and the right interface (not Docker/VM).
5. `/api/devices`: your router and your own PC (self=true) appear with MACs.
6. Turn on a phone's Wi-Fi, call `/api/devices?refresh=true`: it appears. Turn off, wait 1-2 min, refresh: reachable=false or gone.
7. Disconnect from the network: `/api/network` returns 503 with a clear message.
8. Call `/api/devices` twice within 10 s: second answer is instant (cache).
Report: OS, Java version, and any stack trace.
