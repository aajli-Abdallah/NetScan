package com.netscan.store;

import com.netscan.model.Device;
import com.netscan.model.DeviceView;
import com.netscan.model.SavedDevice;
import com.netscan.model.UpdateRequest;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class DeviceStore {
    private final DeviceRepository repo;

    public DeviceStore(DeviceRepository repo) {
        this.repo = repo;
    }

    /** Merge one scan into the database. New MAC = unknown device (this computer = known). */
    @Transactional
    public List<DeviceView> sync(List<Device> scanned, Instant now) {
        List<DeviceView> out = new ArrayList<>();
        for (Device d : scanned) {
            DeviceEntity e = null;
            if (d.mac() != null) {
                e = repo.findByMac(d.mac()).orElse(null);
                if (e == null) {
                    e = new DeviceEntity();
                    e.setId(UUID.randomUUID().toString());
                    e.setMac(d.mac());
                    e.setFirstSeen(now);
                    e.setLastSeen(now);
                    e.setLastIp(d.ip());
                    e.setKnown(d.self());
                    if (d.self()) e.setLabel("This computer");
                }
                if (d.reachable()) {
                    e.setLastSeen(now);
                    e.setLastIp(d.ip());
                }
                e = repo.save(e);
            }
            out.add(e == null
                    ? new DeviceView(null, d.ip(), null, null, false, d.reachable(), d.self(), null, null)
                    : new DeviceView(e.getId(), d.ip(), e.getMac(), e.getLabel(), e.isKnown(),
                            d.reachable(), d.self(), e.getFirstSeen(), e.getLastSeen()));
        }
        return out;
    }

    @Transactional(readOnly = true)
    public List<SavedDevice> saved(Boolean known) {
        return repo.findAll(Sort.by(Sort.Direction.DESC, "lastSeen")).stream()
                .filter(e -> known == null || e.isKnown() == known)
                .map(DeviceStore::toSaved)
                .toList();
    }

    @Transactional
    public SavedDevice update(String id, UpdateRequest req) {
        DeviceEntity e = repo.findById(id).orElseThrow(DeviceStore::notFound);
        if (req.label() != null) {
            String l = req.label().trim();
            if (l.length() > 100)
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Label must be 100 characters or less");
            e.setLabel(l.isEmpty() ? null : l);
        }
        if (req.known() != null) e.setKnown(req.known());
        return toSaved(repo.save(e));
    }

    @Transactional
    public void delete(String id) {
        if (!repo.existsById(id)) throw notFound();
        repo.deleteById(id);
    }

    private static ResponseStatusException notFound() {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, "Device not found");
    }

    private static SavedDevice toSaved(DeviceEntity e) {
        return new SavedDevice(e.getId(), e.getMac(), e.getLastIp(), e.getLabel(), e.isKnown(),
                e.getFirstSeen(), e.getLastSeen());
    }
}
