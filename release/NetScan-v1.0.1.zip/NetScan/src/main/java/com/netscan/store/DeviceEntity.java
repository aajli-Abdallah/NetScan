package com.netscan.store;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "devices")
public class DeviceEntity {
    @Id @Column(length = 36) private String id;
    @Column(nullable = false, unique = true, length = 17) private String mac;
    @Column(length = 100) private String label;
    @Column(nullable = false) private boolean known;
    @Column(name = "last_ip", length = 45) private String lastIp;
    @Column(name = "first_seen", nullable = false) private Instant firstSeen;
    @Column(name = "last_seen", nullable = false) private Instant lastSeen;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getMac() { return mac; }
    public void setMac(String mac) { this.mac = mac; }
    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }
    public boolean isKnown() { return known; }
    public void setKnown(boolean known) { this.known = known; }
    public String getLastIp() { return lastIp; }
    public void setLastIp(String lastIp) { this.lastIp = lastIp; }
    public Instant getFirstSeen() { return firstSeen; }
    public void setFirstSeen(Instant firstSeen) { this.firstSeen = firstSeen; }
    public Instant getLastSeen() { return lastSeen; }
    public void setLastSeen(Instant lastSeen) { this.lastSeen = lastSeen; }
}
