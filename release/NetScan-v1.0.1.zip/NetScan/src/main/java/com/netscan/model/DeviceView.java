package com.netscan.model;

import java.time.Instant;

/** A scanned device merged with its stored data. id/firstSeen/lastSeen are null when no MAC is known. */
public record DeviceView(String id, String ip, String mac, String label, boolean known,
                         boolean reachable, boolean self, Instant firstSeen, Instant lastSeen) {}
