package com.netscan.web;

import com.netscan.model.SavedDevice;
import com.netscan.model.UpdateRequest;
import com.netscan.store.DeviceStore;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/saved")
public class SavedDeviceController {
    private final DeviceStore store;

    public SavedDeviceController(DeviceStore store) {
        this.store = store;
    }

    @GetMapping
    public List<SavedDevice> list(@RequestParam(required = false) Boolean known) {
        return store.saved(known);
    }

    @PatchMapping("/{id}")
    public SavedDevice update(@PathVariable String id, @RequestBody UpdateRequest req) {
        return store.update(id, req);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) {
        store.delete(id);
    }
}
