package com.netscan.model;

import java.time.Instant;

public record SavedDevice(String id, String mac, String lastIp, String label, boolean known,
                          Instant firstSeen, Instant lastSeen) {}
