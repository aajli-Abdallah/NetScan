package com.netscan.model;

/** reachable=false with a MAC means "in ARP cache only" (maybe offline or blocking probes). */
public record Device(String ip, String mac, boolean reachable, boolean self) {}
