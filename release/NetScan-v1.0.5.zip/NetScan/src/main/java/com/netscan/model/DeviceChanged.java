package com.netscan.model;

/** Spring application event published after a device change was recorded. */
public record DeviceChanged(DeviceEvent event) {}
