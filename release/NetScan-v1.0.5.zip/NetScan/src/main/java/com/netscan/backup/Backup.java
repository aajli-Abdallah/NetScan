package com.netscan.backup;

import java.time.Instant;
import java.util.List;

/** Backup file format. Unknown fields are ignored on import, so older apps can read newer files. */
public record Backup(String appVersion, Integer format, Instant exportedAt, List<Dev> devices) {
    public record Dev(String id, String mac, String label, boolean known, String vendor, String hostname,
                      String lastIp, Instant firstSeen, Instant lastSeen, String openPorts,
                      Instant portsScannedAt) {}
}
