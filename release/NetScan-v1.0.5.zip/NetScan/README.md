# NetScan v1.0.5

Home network scanner and intruder alert. Java 21, Spring Boot 3.3, Maven. Offline, one user, no cloud.
Lists devices on your LAN, remembers them, watches for changes, and alerts you when an unknown device joins.

## Run
```
mvn test
mvn spring-boot:run
```
Open http://localhost:8080/ and sign in.
Run it directly on your machine, not in Docker (a container cannot see your LAN). Only scan networks you own or may scan.

## Login
- User: `admin` (`netscan.security.username`).
- First start: a random password is logged once (`FIRST RUN - ...`) and stored hashed in `data/admin.hash`. Delete that file to get a new one.
- Or choose your own with the environment variable `NETSCAN_SECURITY_PASSWORD`. Never commit passwords.
- The server listens on 127.0.0.1 only. If you open it to your LAN (`server.address`), put HTTPS in front of it first.

## What you get
- Radar page: devices as dots (green known, red pulsing unknown, grey offline, cyan this computer). Click a dot to label it, mark it known, scan ports, or forget it. Live updates, tiles, toasts, desktop notifications.
- Scans every 5 minutes (`netscan.scan-interval`). A device is offline after 2 missed scans.
- History of JOINED / ONLINE / OFFLINE events (kept 90 days).
- Vendor names, hostnames, quick port scan (on request only).
- Alerts for new unknown MACs: page, log, optional phone push (ntfy, Discord, Telegram, Slack). The first scan on a fresh database is a baseline without alerts.
- Backup: JSON backup, CSV exports, restore with preview (Merge or Replace). A daily copy is written to `data/backups`. Keep one copy outside this PC.

## Optional setup
- Full vendor list: `mkdir data`, then `curl -L -o data/oui.csv https://standards-oui.ieee.org/oui/oui.csv`, restart. If blocked, save the file from a browser.
- Phone push: set `netscan.alert.webhook-url` (or env `NETSCAN_ALERT_WEBHOOK_URL`) and `netscan.alert.webhook-format` (`text`, `discord`, `telegram`, `slack`). Use the "Test alert" button.

## Data
H2 file in `./data` (database, hash file, backups). Flyway migrations V1 to V3. Back up by downloading the JSON, or copy the `data` folder while the app is stopped.

## Docs
`docs/BLUEPRINT.md` is the project memory (architecture, API, config, decisions, limits, next ideas). `docs/TESTING.md` has the manual test lists. `CHANGELOG.md` has the history.
